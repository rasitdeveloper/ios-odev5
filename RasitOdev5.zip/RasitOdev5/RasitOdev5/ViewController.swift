//
//  ViewController.swift
//  RasitOdev5
//
//  Created by Rasit on 4.10.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var additionOutlet: UIButton!
    @IBOutlet weak var equalOutlet: UIButton!
    
    var content = [String]()
    var secretContent = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultLabel.text = ""
        additionOutlet.isEnabled = false
        equalOutlet.isEnabled = false
    }


    @IBAction func btnSeven(_ sender: UIButton) {
        resultLabel.text!.append("7")
        secretContent.append("7")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnEight(_ sender: UIButton) {
        resultLabel.text!.append("8")
        secretContent.append("8")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnNine(_ sender: UIButton) {
        resultLabel.text!.append("9")
        secretContent.append("9")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnFour(_ sender: UIButton) {
        resultLabel.text!.append("4")
        secretContent.append("4")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnFive(_ sender: UIButton) {
        resultLabel.text!.append("5")
        secretContent.append("5")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnSix(_ sender: UIButton) {
        resultLabel.text!.append("6")
        secretContent.append("6")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnOne(_ sender: UIButton) {
        resultLabel.text!.append("1")
        secretContent.append("1")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnTwo(_ sender: UIButton) {
        resultLabel.text!.append("2")
        secretContent.append("2")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnThree(_ sender: UIButton) {
        resultLabel.text!.append("3")
        secretContent.append("3")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnZero(_ sender: UIButton) {
        resultLabel.text!.append("0")
        secretContent.append("0")
        additionOutlet.isEnabled = true
        equalOutlet.isEnabled = true
    }
    
    @IBAction func btnClear(_ sender: UIButton) {
        resultLabel.text = ""
        secretContent = ""
        additionOutlet.isEnabled = false
        equalOutlet.isEnabled = false
    }
    
    @IBAction func btnAddition(_ sender: UIButton) {
        content.append(secretContent)
        content.append("+")
        secretContent = ""
        resultLabel.text!.append("+")
        additionOutlet.isEnabled = false
        equalOutlet.isEnabled = false
    }
    
    @IBAction func btnEqual(_ sender: UIButton) {
        content.append(secretContent)
        secretContent = ""
        //print(content)
        resultLabel.text = ""
        
        
        var result = 0
        var temp1 = 0
        
        var index = 0
        while index < content.count {
            if content[index] != "+" {
                temp1 = Int(content[index])!
                index = index + 1
            } else {
                index = index + 1
                result = result + temp1 + Int(content[index])!
                temp1 = 0
                index = index + 1
            }
            
        }
        
        secretContent = String(result)
        content.removeAll()
        content.append(secretContent)
        resultLabel.text = String(result)
        
    }
    
    
    
    
    
    
}

